# Microsoft Sentinel Google Workspace Reports Data Connector

This repo is a clone of [Azure/Azure-Sentinel:DataConnectors/GoogleWorkspaceReports](https://github.com/Azure/Azure-Sentinel/tree/master/DataConnectors/GoogleWorkspaceReports) with some basic customisations.

## Setup

To be able to deploy and use the data connector you'll need to use the customised [get_pickle_string.py](get_pickle_string.py) file to generate the required token.pickle.

1. Get your `credental.json` file from the GCP console
2. Install required package `pip install google_auth_oauthlib`
3. Run `python3 get_pickle_string.py` - Login and if successful you should see get a base64 string for the `GooglePickleString` environment variable

## Modifications

<s>This fork/clone primarily just limits the number of Admin Report APIs that get called.</s>
This fork/clone allows you to configure the desired log sources (activities) by using a comma separated environment string `auditLogTypes` . Currently we use the following activities:

```plain
access_transparency,admin,gcp,groups,groups_enterprise,login,meet,mobile,rules,saml,token,user_accounts,context_aware_access,chrome
```

### Available activities

```python
# Available Google audit logs - https://support.google.com/a/answer/9725452?hl=en&ref_topic=9027054
activities = [
            "access_transparency", # See Google staff actions' when accessing your data
            "admin", # View admin activity in the Google Admin console
            "calendar",
            "chat",
            "drive",
            "gcp",
            "gplus",
            "groups", # View user changes to groups in Google Groups
            "groups_enterprise", # See Admin console actions on groups and group memberships
            "jamboard",
            "login", # Track user sign-in activity
            "meet",
            "mobile",
            "rules",
            "saml", # View your users' sign-ins to SAML applications
            "token", # Track third-party app usage and data-access requests
            "user_accounts", # View user activity across their accounts
            "context_aware_access",
            "chrome", # View Chrome events for your organization
            "data_studio"
            ]
```

## Deploy (ARM Template)

Browse to [github.com/esecnyoung/azure-templates](https://github.com/esecnyoung/azure-templates/tree/main/Microsoft-Sentinel/DataConnectors/GoogleWorkspaceReports) and click the `Deploy` button.

Or click this button

[![Deploy to Azure](https://aka.ms/deploytoazurebutton)](https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2Fesecnyoung%2Fazure-templates%2Fmain%2FMicrosoft-Sentinel%2FDataConnectors%2FGoogleWorkspaceReports%2FGoogleWorkspaceReports.json)

## Deploy (manually)

```bash
func azure functionapp publish gworkspacevwkiv2y6m4rvm --python
```

### Create a Zip Deployment

Requires docker to build native dependencies.

```bash
# First build
func pack --build-native-deps
# Subsequent builds (doesn't require docker)
func pack # --build-native-deps
# pip install  --target ".python_packages/lib/site-packages"  -r requirements.txt    
# zip -r GWorkspaceReportsAPISentinelConn.zip GWorkspaceReportsAPISentinelConnector .python_packages host.json proxies.json requirements.txt
```
